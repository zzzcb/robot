# 1. 导入依赖包
import socket

# 2. 创建socket
# 参数1：IP地址类型(AddressFamily(地址簇)) IPv4：socket.AF_INET
# 参数2：传输类型 Type(类型)
#      UDP协议：socket.SOCK_DGRAM
#      TCP协议：socket.SOCK_STREAM
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 3. 使用socket


# 4. 关闭socket
udp_socket.close()