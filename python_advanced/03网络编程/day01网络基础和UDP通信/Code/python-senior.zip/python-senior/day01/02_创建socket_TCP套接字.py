# 1. 导入依赖包
import socket

# 2. 创建 tcp socket
# 参数1：IP地址类型(AddressFamily(地址簇)) IPv4：socket.AF_INET
# 参数2：传输类型 Type(类型)
#      UDP协议：socket.SOCK_DGRAM
#      TCP协议：socket.SOCK_STREAM (默认值)
tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 3. 使用socket


# 4. 关闭socket
tcp_socket.close()