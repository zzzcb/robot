# 1.导入依赖
import socket

# 2.创建udp的套接字
# IP地址类型： socket.AF_INET     IPv4
# 传输协议类型：socket.SOCK_DGRAM  UDP协议
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 绑定udp端口号
# 一般这里绑定的ip地址填空字符串即可
# 可以接收所有网卡的所在网络的消息
udp_socket.bind(("", 3333))

# 使用recvfrom接收数据
recv_data = udp_socket.recvfrom(1024)

try:
    msg = recv_data[0].decode("gbk")
except :
    msg = recv_data[0].decode()

print("接收到来自 {} 的消息：{}".format(recv_data[1], msg))

# 关闭套接字
udp_socket.close()