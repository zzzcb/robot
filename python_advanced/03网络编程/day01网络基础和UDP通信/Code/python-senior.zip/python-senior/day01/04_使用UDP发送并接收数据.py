# 1.导入依赖
import socket

# 2.创建udp的套接字
# IP地址类型： socket.AF_INET     IPv4
# 传输协议类型：socket.SOCK_DGRAM  UDP协议
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 3. 使用socket发送数据
# sendto是udp用来发送数据用的函数
# 参数一：要发送的数据（字节数组）
#    通过encode()对数据进行编码，win10，ubuntu默认UTF-8, utf8
# 参数二：接收者的（IP地址&端口）元组
#    元素1：IP地址（字符串）
#    元素2：端口号（整数）
content = "约吗？"
# content = input("输入发送的内容:\n")
bytes_data = content.encode()
udp_socket.sendto(bytes_data, ("192.168.37.41", 6666))

# 4. 使用recvfrom接收数据
# bufsize 缓冲区大小, 设置最大的接收字节数
# 此代码会进入阻塞状态，等待接受消息
# 一旦有消息进来，阻塞就自动释放
# 得到的数据类型 tuple：(b'\xd4\xbc123', ('127.0.0.1', 8888))
#   元素1：接收到的数据（字节数组）
#   元素2：发送者的（IP,端口）元组
recv_data = udp_socket.recvfrom(1024)

data_ = recv_data[0]
print(data_)
try:
    msg = data_.decode("gbk")
except Exception as e:
    print("gbk解析失败，尝试使用默认编码utf8")
    msg = data_.decode()

print("接收到来自 {} 的消息：{}".format(recv_data[1], msg))

# 5.关闭套接字
udp_socket.close()