# 1.导入依赖
import socket

# 2.创建udp的套接字
# IP地址类型： socket.AF_INET     IPv4
# 传输协议类型：socket.SOCK_DGRAM  UDP协议
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 3. 使用socket发送数据
# 对字符串进行编码
# sendto是udp用来发送数据用的函数
# 需要传入两个参数：
# 参数一：要发送的数据（字节数组）
# 参数二：接收者的（IP地址&端口）元组
#    元素1：IP地址（字符串）
#    元素2：端口号（整数）

bytes_data = "哈哈".encode()
udp_socket.sendto(bytes_data, ("127.0.0.1", 8888))

# 4.关闭套接字
udp_socket.close()