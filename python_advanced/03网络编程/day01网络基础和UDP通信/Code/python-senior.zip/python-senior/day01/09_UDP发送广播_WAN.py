# 导入依赖
from socket import *

# 创建socket对象
udp_socket = socket(AF_INET, SOCK_DGRAM)

# 设置允许发送全局广播
# 参数1：设置影响范围，SOL_SOCKET 当前socket对象
# 参数2：设置属性名， SO_BROADCAST 设置广播属性
# 参数2：设置属性值
udp_socket.setsockopt(SOL_SOCKET, SO_BROADCAST, True)

# 发送广播
udp_socket.sendto("大家好！准备吃饭！".encode(),
                  ("255.255.255.255", 8888))

# 关闭
udp_socket.close()