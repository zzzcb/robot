# 导入依赖
from socket import *

# 创建socket对象
udp_socket = socket(AF_INET, SOCK_DGRAM)

udp_socket.sendto("大家好！".encode(), ("192.168.37.255", 8888))

# 关闭
udp_socket.close()