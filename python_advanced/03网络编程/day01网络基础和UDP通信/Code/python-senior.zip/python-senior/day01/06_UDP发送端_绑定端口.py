# 1.导入依赖
import socket

# 2.创建udp的套接字
# IP地址类型： socket.AF_INET     IPv4
# 传输协议类型：socket.SOCK_DGRAM  UDP协议
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 绑定udp端口号
address = ("127.0.0.1", 3333)
udp_socket.bind(address)

# 3. 使用socket发送数据
udp_socket.sendto("约吗？".encode(), ("127.0.0.1", 8888))

# 4. 使用recvfrom接收数据
recv_data = udp_socket.recvfrom(1024)

data_ = recv_data[0]
try:
    msg = data_.decode("gbk")
except :
    msg = data_.decode()

print("接收到来自 {} 的消息：{}".format(recv_data[1], msg))

# 5.关闭套接字
udp_socket.close()