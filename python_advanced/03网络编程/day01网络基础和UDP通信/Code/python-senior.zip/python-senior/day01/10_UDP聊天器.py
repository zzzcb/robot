"""
创建模块：
    send_msg()发送消息
        1. 接收用户输入的ip地址
        2. 接收用户输入的端口号
        3. 接收用户输入的内容
        4. 发送数据sendto
    recv_msg()接收消息
        1. 执行rectfrom阻塞接收数据
    main()显示菜单
        初始化udp套接字
        循环接收用户输入功能序号

"""
from socket import  *
# send_msg()发送消息
def send_msg(udp_socket):
    # 1. 接收用户输入的ip地址
    ip = input("请输入IP地址：")
    # 2. 接收用户输入的端口号
    port = input("请输入端口号：")
    # 3. 接收用户输入的内容
    msg = input("请输入消息内容：")
    # 4. 发送数据sendto
    udp_socket.sendto(msg.encode(), (ip, int(port)))

def recv_msg(udp_socket):
    # recv_msg()接收消息
    # 1. 执行rectfrom阻塞接收数据
    recv_data = udp_socket.recvfrom(1024)
    try:
        msg = recv_data[0].decode()
    except:
        msg = recv_data[0].decode("gbk")

    print("收到来自{}消息：{}".format(recv_data[1], msg))

menu="""**********************
***** 1、发送消息 *****
***** 2、接收消息 *****
***** 3、退出系统 *****
**********************
"""
def main():
    # 初始化udp套接字
    udp_socket = socket(AF_INET, SOCK_DGRAM)
    udp_socket.bind(("", 3333))

    # main()显示菜单
    # 循环接收用户输入功能序号
    while True:
        print(menu)
        select_num = int(input("请输入序号：\n"))
        if select_num == 1:
            # print("发送消息")
            send_msg(udp_socket)
        elif select_num == 2:
            # print("接收消息")
            recv_msg(udp_socket)
        elif select_num == 3:
            break
        else:
            print("请重新输入")


if __name__ == '__main__':
    main()