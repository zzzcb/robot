# 1.导入依赖
import socket

# 2.创建udp的套接字
# IP地址类型： socket.AF_INET     IPv4
# 传输协议类型：socket.SOCK_DGRAM  UDP协议
udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 3. 使用socket发送数据
bytes_data = "约吗？".encode()
udp_socket.sendto(bytes_data, ("192.168.37.41", 6666))

# 4. 使用recvfrom接收数据
# bufsize 缓冲区大小, 设置最大的接收字节数
# 得到的数据类型 tuple：(b'\xd4\xbc123', ('127.0.0.1', 8888))
recv_data = udp_socket.recvfrom(1024)

data_ = recv_data[0]
print(data_)
# 尝试使用gbk解码数据，解码失败，也不要崩溃退出
msg = data_.decode(encoding="gbk", errors="ignore")

print("接收到来自 {} 的消息：{}".format(recv_data[1], msg))

# 5.关闭套接字
udp_socket.close()